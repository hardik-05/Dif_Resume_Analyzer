import json
import os
from flask import Flask, render_template, request, send_from_directory, jsonify, send_file
import os
from flask import Flask, render_template, request, jsonify
import json
import uuid  # Unique IDs
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, jsonify
import json
import uuid  # To generate unique IDs

app = Flask(__name__)

# Load skills from a JSON file (or database in the future)
skills_list = ["Python", "Java", "React", "AWS", "Docker", "Kubernetes", "Pyspark"]

# Function to load job descriptions from file
def load_job_descriptions():
    try:
        with open("job_descriptions.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

# Store job descriptions in memory (loaded from file)
job_descriptions = load_job_descriptions()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload-job-description", methods=["GET"])
def upload_job_description():
    return render_template("upload_job.html", skills=skills_list)

@app.route("/save-job-description", methods=["POST"])
def save_job_description():
    data = request.json
    data["id"] = str(uuid.uuid4())  # Generate unique ID

    job_descriptions.append(data)  # Append new entry

    # Save to JSON file
    with open("job_descriptions.json", "w") as f:
        json.dump(job_descriptions, f, indent=4)

    return jsonify({"message": "Job description saved successfully!", "id": data["id"]})

@app.route("/add-skill", methods=["POST"])
def add_skill():
    new_skill = request.json.get("skill")
    if new_skill and new_skill not in skills_list:
        skills_list.append(new_skill)
    return jsonify({"skills": skills_list})

@app.route("/search-skill", methods=["GET"])
def search_skill():
    query = request.args.get("query", "").lower()
    matching_skills = [skill for skill in skills_list if query in skill.lower()]
    return jsonify({"skills": matching_skills})

# Directory for storing resumes
UPLOAD_FOLDER = "resumes"
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Load job descriptions to get job IDs
def load_job_ids():
    try:
        with open("job_descriptions.json", "r") as f:
            jobs = json.load(f)
            return [job["id"] for job in jobs]  # Extract job IDs
    except (FileNotFoundError, json.JSONDecodeError):
        return []

# Load resumes
def load_resumes():
    try:
        with open("resumes.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

resumes = load_resumes()

@app.route("/upload-resume", methods=["GET"])
def upload_resume():
    job_ids = load_job_ids()
    return render_template("upload_resume.html", job_ids=job_ids)

@app.route("/save-resume", methods=["POST"])
def save_resume():
    files = request.files.getlist("resumeFiles[]")
    candidates = request.form.getlist("candidateNames[]")
    job_ids = request.form.getlist("jobIds[]")
    notes = request.form.getlist("notes[]")

    resume_entries = []
    for i in range(len(files)):
        if files[i]:
            filename = secure_filename(files[i].filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            files[i].save(filepath)  # Save file

            entry = {
                "id": str(uuid.uuid4()),
                "candidateName": candidates[i],
                "jobId": job_ids[i],
                "notes": notes[i],
                "filePath": filepath
            }
            resumes.append(entry)
            resume_entries.append(entry)

    with open("resumes.json", "w") as f:
        json.dump(resumes, f, indent=4)

    return jsonify({"message": "Resumes uploaded successfully!", "resumes": resume_entries})





# Load job-resume mapping
def load_job_resume_data():
    try:
        with open("job_resume_pair.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

job_resume_data = load_job_resume_data()

@app.route("/hiring-status", methods=["GET"])
def hiring_status():
    search_query = request.args.get("search", "").lower()
    
    # Filter jobs based on search
    filtered_jobs = {}
    for job_id, details in job_resume_data.items():
        if search_query in details["role"].lower() or search_query in job_id.lower():
            filtered_jobs[job_id] = details

    return render_template("hiring_status.html", jobs=filtered_jobs or job_resume_data)

@app.route("/hiring-status/<job_id>", methods=["GET"])
def job_resumes(job_id):
    job_details = job_resume_data.get(job_id)

    if not job_details:
        return "Job not found", 404

    # Sort resumes by score (highest first)
    sorted_resumes = sorted(job_details["resumes"], key=lambda x: list(x.values())[0], reverse=True)

    return render_template("job_resumes.html", job_id=job_id, role=job_details["role"], resumes=sorted_resumes)





# Folder paths
REPORTS_FOLDER = "reports"
INTERVIEWS_FILE = "interviews.json"

# Load existing interviews
def load_interviews():
    try:
        with open(INTERVIEWS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

interviews_data = load_interviews()

@app.route("/reports/<resume_id>")
def get_report(resume_id):
    """ Serve the PDF report for the given resume ID """
    return send_from_directory(REPORTS_FOLDER, f"{resume_id}.pdf")

@app.route("/schedule-interview", methods=["POST"])
def schedule_interview():
    """ Store scheduled interview details in JSON """
    data = request.json
    resume_id = data.get("resume_id")
    candidate_name = data.get("candidate_name")
    interview_date = data.get("date")
    interview_time = data.get("time")
    interviewers = data.get("interviewers", [])


    if not (resume_id and candidate_name and interview_date and interview_time):
        return jsonify({"error": "All fields are required"}), 400

    # Append new interview to JSON
    interviews_data[resume_id] = {
        "candidate_name": candidate_name,
        "date": interview_date,
        "time": interview_time,
        "interviewers": interviewers
    }

    with open(INTERVIEWS_FILE, "w") as f:
        json.dump(interviews_data, f, indent=4)

    return jsonify({"message": "Interview Scheduled Successfully"}), 200




# Load interview data from JSON file
INTERVIEW_JSON_PATH = "interviews.json"

def load_interview_data():
    if os.path.exists(INTERVIEW_JSON_PATH):
        with open(INTERVIEW_JSON_PATH, "r") as file:
            return json.load(file)
    return {}

@app.route("/interview_assistance")
def interview_assistance():
    interview_data = load_interview_data()
    return render_template("interview_assistance.html", interview_data=interview_data)

@app.route("/open_pdf/<category>/<resume_id>")
def open_pdf(category, resume_id):
    folder_map = {
        "questions": "assistance_question",
        "mcq": "mcq_questions"
    }
    folder_path = folder_map.get(category, "")
    
    if folder_path:
        file_path = os.path.join(folder_path, f"{resume_id}.pdf")
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=False)
    
    return jsonify({"error": "File not found"}), 404








if __name__ == "__main__":
    app.run(debug=True)

